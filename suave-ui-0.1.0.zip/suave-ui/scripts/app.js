(function () {

	angular.module('suave-ui', [
		'su-templates',
		'su-grid',
		'su-button',
		'su-layers',
		'su-notifier'
	]);

})();
